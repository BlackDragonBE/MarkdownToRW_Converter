﻿namespace WordPressSharp.Models
{
    public enum UserRole
    {
        Administrator,
        Editor,
        Author,
        Contributor
    }
}
