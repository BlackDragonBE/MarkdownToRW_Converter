﻿using CookComputing.XmlRpc;

namespace WordPressSharp.Models
{
	/*
    public class PostType
    {
        [XmlRpcMember("name")]
        public string Name { get; set; }

        [XmlRpcMember("label")]
        public string Label { get; set; }

        [XmlRpcMember("hierarchical")]
        public bool Hierarchical { get; set; }

        [XmlRpcMember("show_ui")]
        public bool ShowUi { get; set; }

        [XmlRpcMember("_builtin")]
        public bool BuiltIn { get; set; }

        [XmlRpcMember("has_archive")]
        public bool HasArchive { get; set; }

        [XmlRpcMember("map_meta_cap")]
        public bool MapMetaCamp { get; set; }

        [XmlRpcMember("menu_position")]
        public int MenuPosition { get; set; }

        [XmlRpcMember("menu_icon")]
        public string MenuIcon { get; set; }

        [XmlRpcMember("show_in_menu")]
        public bool ShowInMenu { get; set; }

        [XmlRpcMember("taxonomies")]
        public Taxonomy[] Taxonomies { get; set; }


    }
	 */
}
