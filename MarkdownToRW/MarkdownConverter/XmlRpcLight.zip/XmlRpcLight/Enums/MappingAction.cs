namespace XmlRpcLight.Enums {
    public enum MappingAction {
        Ignore,
        Error
    }
}